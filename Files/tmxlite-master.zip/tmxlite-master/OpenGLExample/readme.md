OpenGL Example
--------------

Test program demonstrating how one may possibly implement
an orthogonal map renderer using OpenGL, provided by SDL2

Requires SDL2, SDL2_Image, OpenGL and GLM