<?xml version="1.0" encoding="UTF-8"?>
<tileset name="" tilewidth="64" tileheight="64" tilecount="42" columns="6">
 <properties>
  <property name="bool property" type="bool" value="false"/>
  <property name="float property" type="float" value="56.770000000000003"/>
  <property name="int property" type="int" value="12"/>
  <property name="string property" value="shoes"/>
 </properties>
 <image source="tileset.png" trans="ff00ff" width="384" height="448"/>
 <terraintypes>
  <terrain name="brown" tile="-1"/>
  <terrain name="green" tile="-1"/>
 </terraintypes>
 <tile id="0" terrain=",0,,0"/>
 <tile id="22" terrain="1,1,1,"/>
 <tile id="25" terrain=",1,,1"/>
 <tile id="26" terrain="0,,0,"/>
</tileset>
