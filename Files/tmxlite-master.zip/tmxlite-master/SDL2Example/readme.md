SDL2 Example
------------

Test program demonstrating how one may possibly implement
an orthogonal map renderer using SDL2.

Note that this example provides very basic rendering, and
does not support all the features supported by tmxlite,
such as tile flipping/rotation or tilesets which are created
as a collection of images.

It also uses C++ rather than plain C.